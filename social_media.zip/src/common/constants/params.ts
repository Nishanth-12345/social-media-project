
export const localUrl = "http://localhost:3000.com/";
export const cloudName = "dogyht9rh";
export const uploadPreset = "socio-media";